package game;
public class BlessCurseOwner extends ItemAction{
    public BlessCurseOwner(Item _owner, String _name){
        super(_owner, _name);
    }
}
