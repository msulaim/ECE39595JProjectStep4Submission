package game;
public interface InputObserver {

    abstract boolean observerUpdate(char inputChar);
}
