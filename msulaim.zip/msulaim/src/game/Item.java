package game;
public class Item extends Displayable{
    Creature owner;
    public void setOwner(Creature _owner){
        owner = _owner;
    }
    
}
