package game;
public class Structure extends Displayable{
    
}
