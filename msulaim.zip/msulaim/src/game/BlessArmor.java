package game;
public class BlessArmor extends ItemAction{
    public BlessArmor(Item _owner, String _name){
        super(_owner, _name);
    }
}
